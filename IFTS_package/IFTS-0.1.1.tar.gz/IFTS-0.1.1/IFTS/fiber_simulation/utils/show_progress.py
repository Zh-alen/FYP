import time
import tqdm
from tqdm import trange, tqdm
 
#demo1
# def process_bar(percent, start_str='', end_str='', total_length=0):
#     bar = ''.join(["\033[31m%s\033[0m"%'   '] * int(percent * total_length)) + ''
#     bar = '\r' + start_str + bar.ljust(total_length) + ' {:0>4.1f}%|'.format(percent*100) + end_str
#     print(bar, end='', flush=True)
 
 
# for i in range(101):
#     time.sleep(0.1)
#     end_str = '100%'
#     process_bar(i/100, start_str='', end_str=end_str, total_length=15)
 
def process_bar(i, end, discription = 'Processing:'):
    num = i // 2
    if i == end:
        process = "\r" + discription + "[%3s%%]: |%-50s|\n" % (i, '|' * num)
    else:
        process = "\r" + discription + "[%3s%%]: |%-50s|" % (i, '|' * num)
    print(process, end='', flush=True)

def progress_info(total_num, infor_print = 1, discription = 'DSP Processing'):
    if infor_print:
        def run_tqdm(func):
            def wrapper(*args, **kwargs):
                start = time.time()
                print(discription + ' Start!')
                with tqdm(total=total_num) as pbar:
                    pbar.set_description(discription)
                    func(*args, **kwargs, pbar = pbar)
                end = time.time()
                cost_time = end - start
                print(discription + " end with the running time {:.4f} s".format(cost_time))         
            return wrapper
        return run_tqdm
    else:
        def run_func(func):
            def wrapper(*args, **kwargs):
                func()
            return wrapper
        return run_func

def progress_info_return(total_num, infor_print = 1, discription = 'DSP Processing'):
    if infor_print:
        def run_tqdm(func):
            def wrapper(*args, **kwargs):
                start = time.time()
                print(discription + ' Start!')
                with tqdm(total=total_num) as pbar:
                    pbar.set_description(discription)
                    x = func(*args, **kwargs, pbar = pbar)
                end = time.time()
                cost_time = end - start
                print(discription + " end with the running time {:.4f} s".format(cost_time))         
                return x
            return wrapper
        return run_tqdm
    else:
        def run_func(func):
            def wrapper(*args, **kwargs):
                return func(*args, **kwargs)
            return wrapper
        return run_func
           
         
    
if __name__ == '__main__':
    # for i in range(0, 100):
    #     time.sleep(0.1)
    #     process_bar(i+1, 100)
        
    # for i in tqdm.tqdm(range(100)):
    #     time.sleep(0.1)
    with tqdm(total=200, ncols=0) as pbar:
        pbar.set_description('Processing')
        # total表示总的项目, 循环的次数20*10(每次更新数目) = 200(total)
        for i in range(20):
            # 进行动作, 这里是过0.1s
            for j in range(10):
                time.sleep(0.1)
                # 进行进度更新, 这里设置10个
                pbar.update(1)